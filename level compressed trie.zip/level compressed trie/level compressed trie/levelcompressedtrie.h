#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <stack>

//#define DEBUG

/* Structure of binary trie node */
struct BtNode{
    BtNode  *left;      /* for 0 */
    BtNode  *right;     /* for 1 */
    int     verdict;
    int skip;
    int segment[32];
};

stack <node*> leftnodestack;
stack <node*> rightnodestack;

/* Initialize binary trie node */
BtNode* init_btnode(){
    BtNode *ret = (BtNode *)malloc(sizeof(BtNode));
    ret->left = NULL;
    ret->right = NULL;
    ret->verdict = -1;
    ret->skip=0;
    ret->segment=0;
    return ret;
}

/* Clean up binary trie */
void free_bt(BtNode *root){

    if(root->left != NULL){
        free_bt(root->left);
    }
    if(root->right != NULL){
        free_bt(root->right);
    }

    free(root);
}

/* Insert a rule */
void insert_rule(BtNode *root, uint32_t prefix, int prelen, int portnum){
    static int     n_rules = 0;

#ifdef DEBUG
    uint32_t prefix_r = htonl(prefix);
    fprintf(stderr, "Insert rule: %-15s(%08x)/%d    %d\n", 
            inet_ntoa(*(struct in_addr *)&prefix_r), 
            prefix, prelen, portnum);
#endif

    n_rules ++;

    /* default rule: if packet matches none of the rules, 
     * it will match this default rule, i.e. 0.0.0.0/0 */
    if( prelen == 0 ){
        root->verdict = portnum;
        return;
    }

    uint32_t    temp_prefix = prefix;
    BtNode      *curr_node = root;
    for(int i=0 ; i<prelen ; i++){
        int     curr_bit = (temp_prefix & 0x80000000) ? 1 : 0;
        if(curr_bit == 0){
            if(curr_node->left == NULL){
                curr_node->left = init_btnode();
            }
            curr_node = curr_node->left;
        }
        else{
            if(curr_node->right == NULL){
                curr_node->right = init_btnode();
            }
            curr_node = curr_node->right;
        }
        temp_prefix = temp_prefix << 1;
    }

    if( curr_node->verdict != -1 ){
        fprintf(stderr, "Error: Rule #%d - overwriting a previous rule!! \n", n_rules);
    }
    curr_node->verdict = portnum;
}


void preorder(BtNode *start_node, int verdict){

   if ( start_node == NULL ) return;

   if ( start_node -> right == NULL && start_node -> left == NULL ){
      if ( start_node -> verdict == -1 ){
         printf("No portnum");
      }
      return;
   }

   if(start_node -> verdict != -1){
    verdict = start_node -> verdict;
       start_node->verdict = -1;
   }
if ( start_node -> left == NULL ){
      BtNode *temp = init_btnode();
      temp->verdict = verdict;
      start_node -> left = temp;
   }

   if ( start_node -> right == NULL ){
      BtNode *temp = init_btnode();
      temp->verdict = verdict;
      start_node -> right = temp;
   }
 
   preorder(start_node -> left, verdict);
   preorder(start_node -> right, verdict);
   return; 

}

void disjointprefixtrie(BtNode *start_node)
{
  if(start_node == NULL){
    return;
  }else{
        preorder(start_node, start_node->verdict);
  }
}


void *compress_lefttrie(BtNode *start_node, int verdict, int prelen)
{
  int count=0,n,array[32],i,z;
  node *ncurrent=NULL;
  node *nprev=NULL;
  nprev = *start_node;
  ncurrent = nprev;

  compress:if ((ncurrent->verdict==-1))
  {
    for(;;)
    {
      if(ncurrent->left==NULL && ncurrent->right==NULL)
      {
        break;
      }
      if((ncurrent->left!=NULL) && (ncurrent->right!=NULL))
      {
          leftnodestack.push(ncurrent);
          if(!rightnodestack.empty())
          {
                       if(leftnodestack.top()== rightnodestack.top())
                       leftnodestack.pop();
          }
          n = prelen;
          if(n!=0){
               
                    for(i=0;i<n;i++){
                    ncurrent->segment[i]= array[i];
                    ncurrent->skip=count;
                    count=0;
                    break;
                    }   
          if((ncurrent->verdict!=-1)) 
                    {  
              oprn: n=prelen;
                    if(n!=0){
                    for(z=0;z<n;z++){
                    array[z]=ncurrent->segment[z];
                    count=ncurrent->skip;
                    count=0;
                    break;
                    }  
                    if((ncurrent->left!=NULL) && (ncurrent->right==NULL))
                    {
                               if(ncurrent->verdict!=-1)
                               goto oprn;
                    count++;
                    array[i]=0;
                    i++;
                    ncurrent=ncurrent->left;
                    }
                     if((ncurrent->left==NULL) && (ncurrent->right!=NULL))
                    {
                                if(ncurrent->verdict!=-1)
                               goto oprn;
                    count++;    
                    array[i]=1;
                    i++;
                    ncurrent= ncurrent->right;
                    }
                    }
                    if(n!=0)
                    {
                    if(nprev->left==NULL && nprev->right!=NULL)
                    {
                    nprev->right=ncurrent;
                    goto jump;
                    }
                    nprev->right=ncurrent;
                    jump:compress_righttrie(&ncurrent);
                    return NULL;
                    }
                    if((ncurrent->left==NULL) && (ncurrent->right==NULL))
                    {
                       return NULL;
                    }
                       if (ncurrent->port!=0 && (ncurrent->left==NULL && ncurrent->right!=NULL ))
                    {
                              ncurrent= ncurrent->right;
                              goto compress;
                    } 
        nprev=ncurrent;
        ncurrent=(ncurrent->left);
        goto compress;   
        }

      }
    }
  }
}



void *compress_righttrie(BtNode *start_node, int verdict, int prelen)
{
  int count=0,n,array[32],i,z;
  node *mcurrent=NULL;
  node *mprev=NULL;
  mprev = *start_node;
  mcurrent = mprev;

  compress:if ((mcurrent->verdict==-1))
  {
    for(;;)
    {
      if(mcurrent->left==NULL && mcurrent->right==NULL)
      {
        break;
      }
      if((mcurrent->left!=NULL) && (mcurrent->right!=NULL))
      {
          rightnodestack.push(mcurrent);
          if(!leftnodestack.empty())
          {
                       if(rightnodestack.top()== leftnodestack.top())
                       rightnodestack.pop();
          }
          n = prelen;
          if(n!=0){
               
                    for(i=0;i<n;i++){
                    mcurrent->segment[i]= array[i];
                    mcurrent->skip=count;
                    count=0;
                    break;
                    }   
          if((mcurrent->verdict!=-1)) 
                    {  
              oprn: n=prelen;
                    if(n!=0){
                    for(z=0;z<n;z++){
                    array[z]=mcurrent->segment[z];
                    count=mcurrent->skip;
                    count=0;
                    break;
                    }  
                    if((mcurrent->left!=NULL) && (mcurrent->right==NULL))
                    {
                               if(mcurrent->verdict!=-1)
                               goto oprn;
                    count++;
                    array[i]=0;
                    i++;
                    mcurrent=mcurrent->left;
                    }
                     if((mcurrent->left==NULL) && (mcurrent->right!=NULL))
                    {
                                if(mcurrent->verdict!=-1)
                               goto oprn;
                    count++;    
                    array[i]=1;
                    i++;
                    ncurrent= ncurrent->right;
                    }
                    }
                    if(n!=0)
                    {
                    if(mprev->right==NULL && mprev->left!=NULL)
                    {
                    mprev->left=mcurrent;
                    goto jump;
                    }
                    mprev->right=mcurrent;
                    jump:compress_righttrie(&ncurrent);
                    return NULL;
                    }
                    if((mcurrent->left==NULL) && (mcurrent->right==NULL))
                    {
                       return NULL;
                    }
                       if (mcurrent->port!=0 && (mcurrent->left!=NULL && mcurrent->right==NULL ))
                    {
                              mcurrent= mcurrent->left;
                              goto compress;
                    } 
        mprev=mcurrent;
        mcurrent=(mcurrent->right);
        goto compress;   
        }

      }
    }
  }
}

void create_pctrie()
{
  int i;
  node *temp=NULL
  node *temp1=NULL;
  init_btnode();
  compress_lefttrie(root,verdict,prelen);
        
        for(i=0;i<32;i++)
          {
                while (!leftnodestack.empty())
                  {
                        temp= leftnodestack.top();
                        compress_righttrie(&temp);
                        leftnodestack.pop();
                  }
                while (!rightnodestack.empty())
                  {
                        temp1= rightnodestack.top();
                        compress_lefttrie(&temp1);
                        rightnodestack.pop();
                  }

          }
                                           
printf("\nPCTrie Creation Complete\n");
}        

/* Look up an IP address (represented in a uint32_t) */
int lookup_ip(BtNode *root, uint32_t ip){
    uint32_t    temp_ip = ip;
    BtNode      *curr_node = root;
    int         curr_verdict = root->verdict;
    int         curr_bit = 0;

    while(1){
        curr_bit = (temp_ip & 0x80000000) ? 1 : 0;
        if(curr_bit == 0){
            if(curr_node->left == NULL)     return curr_verdict;
            else                            curr_node = curr_node->left;
        }
        else{
            if(curr_node->right == NULL)    return curr_verdict;
            else                            curr_node = curr_node->right;
        }

        /* update verdict if current node has an non-empty verdict */
        curr_verdict = (curr_node->verdict == -1) ? curr_verdict : curr_node->verdict;
        temp_ip = temp_ip << 1;
    }
}
